document.addEventListener('DOMContentLoaded', function () {
  // Puedes agregar lógica adicional aquí si es necesario
});
